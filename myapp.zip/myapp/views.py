# Create your views here.
from django.shortcuts import render, redirect
from django.contrib import messages  # Import messages module
from .models import UserProfile

def register(request):
    if request.method == 'POST':
        full_name = request.POST['full_name']
        username = request.POST['username']
        email = request.POST['email']
        phone_number = request.POST['phone_number']
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']  # Add this line
        gender = request.POST['gender']

       
        if password != confirm_password:
            messages.error(request, "Password and Confirm Password do not match.")
            return redirect('register')

        # Create a new user profile
        user_profile = UserProfile(
            full_name=full_name,
            username=username,
            email=email,
            phone_number=phone_number,
            password=password,
            gender=gender
        )
        user_profile.save()

       
        return render(request,'myapp/success.html')

    return render(request, 'myapp/index.html')
