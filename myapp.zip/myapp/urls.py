from django.urls import path,include
from . import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('success/',views.register,name='success'),
    # Add other URL patterns as needed
]
